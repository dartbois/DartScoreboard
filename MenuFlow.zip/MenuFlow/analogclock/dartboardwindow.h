#ifndef DARTBOARDWINDOW_H
#define DARTBOARDWINDOW_H

#include <QMainWindow>
#include <QObject>
#include <QQuickItem>
#include <QWidget>
#include "rasterwindow.h"

//Declare the DartboardWindow class as a subclass of RasterWindow
class DartboardWindow : public RasterWindow
{
public:
    DartboardWindow();
    QWidget* sector(DartboardWindow);
protected:
    void render(QPainter *p) override;

};

#endif // DARTBOARDWINDOW_H
