/********************************************************************************
** Form generated from reading UI file 'manageplayermenu.ui'
**
** Created by: Qt User Interface Compiler version 5.14.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MANAGEPLAYERMENU_H
#define UI_MANAGEPLAYERMENU_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialog>
#include <QtWidgets/QDialogButtonBox>
#include <QtWidgets/QLabel>

QT_BEGIN_NAMESPACE

class Ui_ManagePlayerMenu
{
public:
    QDialogButtonBox *buttonBox;
    QLabel *label;

    void setupUi(QDialog *ManagePlayerMenu)
    {
        if (ManagePlayerMenu->objectName().isEmpty())
            ManagePlayerMenu->setObjectName(QString::fromUtf8("ManagePlayerMenu"));
        ManagePlayerMenu->resize(400, 300);
        buttonBox = new QDialogButtonBox(ManagePlayerMenu);
        buttonBox->setObjectName(QString::fromUtf8("buttonBox"));
        buttonBox->setGeometry(QRect(30, 240, 341, 32));
        buttonBox->setOrientation(Qt::Horizontal);
        buttonBox->setStandardButtons(QDialogButtonBox::Cancel|QDialogButtonBox::Ok);
        label = new QLabel(ManagePlayerMenu);
        label->setObjectName(QString::fromUtf8("label"));
        label->setGeometry(QRect(80, 150, 241, 16));

        retranslateUi(ManagePlayerMenu);
        QObject::connect(buttonBox, SIGNAL(accepted()), ManagePlayerMenu, SLOT(accept()));
        QObject::connect(buttonBox, SIGNAL(rejected()), ManagePlayerMenu, SLOT(reject()));

        QMetaObject::connectSlotsByName(ManagePlayerMenu);
    } // setupUi

    void retranslateUi(QDialog *ManagePlayerMenu)
    {
        ManagePlayerMenu->setWindowTitle(QCoreApplication::translate("ManagePlayerMenu", "Dialog", nullptr));
        label->setText(QCoreApplication::translate("ManagePlayerMenu", "This is where you can manage players!", nullptr));
    } // retranslateUi

};

namespace Ui {
    class ManagePlayerMenu: public Ui_ManagePlayerMenu {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MANAGEPLAYERMENU_H
