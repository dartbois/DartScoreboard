/********************************************************************************
** Form generated from reading UI file 'startupmenu.ui'
**
** Created by: Qt User Interface Compiler version 5.14.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_STARTUPMENU_H
#define UI_STARTUPMENU_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialog>
#include <QtWidgets/QLabel>
#include <QtWidgets/QPushButton>

QT_BEGIN_NAMESPACE

class Ui_StartupMenu
{
public:
    QPushButton *pushButton;
    QPushButton *GameButton;
    QLabel *label;

    void setupUi(QDialog *StartupMenu)
    {
        if (StartupMenu->objectName().isEmpty())
            StartupMenu->setObjectName(QString::fromUtf8("StartupMenu"));
        StartupMenu->resize(400, 300);
        pushButton = new QPushButton(StartupMenu);
        pushButton->setObjectName(QString::fromUtf8("pushButton"));
        pushButton->setGeometry(QRect(40, 220, 111, 32));
        GameButton = new QPushButton(StartupMenu);
        GameButton->setObjectName(QString::fromUtf8("GameButton"));
        GameButton->setGeometry(QRect(240, 220, 112, 32));
        label = new QLabel(StartupMenu);
        label->setObjectName(QString::fromUtf8("label"));
        label->setGeometry(QRect(20, 50, 351, 121));

        retranslateUi(StartupMenu);

        QMetaObject::connectSlotsByName(StartupMenu);
    } // setupUi

    void retranslateUi(QDialog *StartupMenu)
    {
        StartupMenu->setWindowTitle(QCoreApplication::translate("StartupMenu", "Dialog", nullptr));
        pushButton->setText(QCoreApplication::translate("StartupMenu", "Manage Mode", nullptr));
        GameButton->setText(QCoreApplication::translate("StartupMenu", "Game Mode", nullptr));
        label->setText(QCoreApplication::translate("StartupMenu", "<html><head/><body><p align=\"center\">Welcome to the Dart League Scoreboard Program!</p><p><br/></p><p align=\"center\">Would you like to manage the league or play a game?</p></body></html>", nullptr));
    } // retranslateUi

};

namespace Ui {
    class StartupMenu: public Ui_StartupMenu {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_STARTUPMENU_H
