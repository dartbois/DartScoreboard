#ifndef BOARDSECTOR_H
#define BOARDSECTOR_H

#include <QMainWindow>
#include <QObject>
#include <QWidget>

class BoardSector : public QWidget
{
    Q_OBJECT
public:
    explicit BoardSector(QWidget *parent = nullptr);
    void clickableZones(QWidget* q);
signals:

};

#endif // BOARDSECTOR_H
