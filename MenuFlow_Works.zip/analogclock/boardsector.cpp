#include "boardsector.h"

BoardSector::BoardSector(QWidget *parent) : QWidget(parent)
{

}
void BoardSector::clickableZones(QWidget *q)
{
    QRect clickableRect(0, 0, 100, 100);
}
