/********************************************************************************
** Form generated from reading UI file 'managechoicemenu.ui'
**
** Created by: Qt User Interface Compiler version 5.14.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MANAGECHOICEMENU_H
#define UI_MANAGECHOICEMENU_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialog>
#include <QtWidgets/QLabel>
#include <QtWidgets/QPushButton>

QT_BEGIN_NAMESPACE

class Ui_ManageChoiceMenu
{
public:
    QPushButton *pushButton;
    QPushButton *managePlayers;
    QLabel *label;
    QLabel *label_2;

    void setupUi(QDialog *ManageChoiceMenu)
    {
        if (ManageChoiceMenu->objectName().isEmpty())
            ManageChoiceMenu->setObjectName(QString::fromUtf8("ManageChoiceMenu"));
        ManageChoiceMenu->resize(400, 300);
        pushButton = new QPushButton(ManageChoiceMenu);
        pushButton->setObjectName(QString::fromUtf8("pushButton"));
        pushButton->setGeometry(QRect(220, 220, 121, 32));
        managePlayers = new QPushButton(ManageChoiceMenu);
        managePlayers->setObjectName(QString::fromUtf8("managePlayers"));
        managePlayers->setGeometry(QRect(30, 220, 121, 32));
        managePlayers->setProperty("playerManage", QVariant(true));
        label = new QLabel(ManageChoiceMenu);
        label->setObjectName(QString::fromUtf8("label"));
        label->setGeometry(QRect(30, 70, 341, 61));
        label_2 = new QLabel(ManageChoiceMenu);
        label_2->setObjectName(QString::fromUtf8("label_2"));
        label_2->setGeometry(QRect(30, 110, 281, 16));

        retranslateUi(ManageChoiceMenu);
        QObject::connect(managePlayers, SIGNAL(clicked()), ManageChoiceMenu, SLOT(accept()));

        QMetaObject::connectSlotsByName(ManageChoiceMenu);
    } // setupUi

    void retranslateUi(QDialog *ManageChoiceMenu)
    {
        ManageChoiceMenu->setWindowTitle(QCoreApplication::translate("ManageChoiceMenu", "Dialog", nullptr));
        pushButton->setText(QCoreApplication::translate("ManageChoiceMenu", "Manage Games", nullptr));
        managePlayers->setText(QCoreApplication::translate("ManageChoiceMenu", "Manage Players", nullptr));
        label->setText(QCoreApplication::translate("ManageChoiceMenu", "Would you like to manage the players in the league", nullptr));
        label_2->setText(QCoreApplication::translate("ManageChoiceMenu", "or manage the games in the league?", nullptr));
    } // retranslateUi

};

namespace Ui {
    class ManageChoiceMenu: public Ui_ManageChoiceMenu {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MANAGECHOICEMENU_H
