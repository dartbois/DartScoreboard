/********************************************************************************
** Form generated from reading UI file 'scorerview.ui'
**
** Created by: Qt User Interface Compiler version 5.14.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_SCORERVIEW_H
#define UI_SCORERVIEW_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialog>
#include <QtWidgets/QFrame>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QRadioButton>
#include <QtWidgets/QTableWidget>

QT_BEGIN_NAMESPACE

class Ui_ScorerView
{
public:
    QFrame *line;
    QFrame *line_2;
    QFrame *line_3;
    QFrame *line_4;
    QLabel *label;
    QLabel *label_2;
    QLabel *label_3;
    QFrame *line_5;
    QTableWidget *tableWidget;
    QFrame *line_6;
    QFrame *line_7;
    QLabel *label_4;
    QPushButton *pushButton;
    QPushButton *pushButton_2;
    QLabel *label_5;
    QRadioButton *PlayerOneStats;
    QRadioButton *PlayerTwoStats;
    QRadioButton *PlayerOneAndPlayerTwoStats;
    QRadioButton *CurrentPlayerStats;
    QRadioButton *NumberOf180s;
    QRadioButton *WinPercentages;
    QRadioButton *PersonalStats;
    QRadioButton *MatchStats;
    QRadioButton *RankedStats;
    QFrame *line_8;
    QLabel *label_6;
    QPushButton *pushButton_3;
    QPushButton *pushButton_4;

    void setupUi(QDialog *ScorerView)
    {
        if (ScorerView->objectName().isEmpty())
            ScorerView->setObjectName(QString::fromUtf8("ScorerView"));
        ScorerView->resize(1245, 680);
        line = new QFrame(ScorerView);
        line->setObjectName(QString::fromUtf8("line"));
        line->setGeometry(QRect(143, 0, 20, 561));
        line->setMidLineWidth(2);
        line->setFrameShape(QFrame::VLine);
        line->setFrameShadow(QFrame::Sunken);
        line_2 = new QFrame(ScorerView);
        line_2->setObjectName(QString::fromUtf8("line_2"));
        line_2->setGeometry(QRect(0, 550, 1261, 20));
        line_2->setMidLineWidth(2);
        line_2->setFrameShape(QFrame::HLine);
        line_2->setFrameShadow(QFrame::Sunken);
        line_3 = new QFrame(ScorerView);
        line_3->setObjectName(QString::fromUtf8("line_3"));
        line_3->setGeometry(QRect(150, 110, 201, 16));
        line_3->setMidLineWidth(2);
        line_3->setFrameShape(QFrame::HLine);
        line_3->setFrameShadow(QFrame::Sunken);
        line_4 = new QFrame(ScorerView);
        line_4->setObjectName(QString::fromUtf8("line_4"));
        line_4->setGeometry(QRect(340, 0, 20, 121));
        line_4->setMidLineWidth(2);
        line_4->setFrameShape(QFrame::VLine);
        line_4->setFrameShadow(QFrame::Sunken);
        label = new QLabel(ScorerView);
        label->setObjectName(QString::fromUtf8("label"));
        label->setGeometry(QRect(10, 0, 121, 41));
        label_2 = new QLabel(ScorerView);
        label_2->setObjectName(QString::fromUtf8("label_2"));
        label_2->setGeometry(QRect(10, 150, 141, 31));
        label_3 = new QLabel(ScorerView);
        label_3->setObjectName(QString::fromUtf8("label_3"));
        label_3->setGeometry(QRect(160, 10, 151, 31));
        line_5 = new QFrame(ScorerView);
        line_5->setObjectName(QString::fromUtf8("line_5"));
        line_5->setGeometry(QRect(1090, 0, 20, 561));
        line_5->setFrameShape(QFrame::VLine);
        line_5->setFrameShadow(QFrame::Sunken);
        tableWidget = new QTableWidget(ScorerView);
        tableWidget->setObjectName(QString::fromUtf8("tableWidget"));
        tableWidget->setGeometry(QRect(1100, 0, 151, 561));
        line_6 = new QFrame(ScorerView);
        line_6->setObjectName(QString::fromUtf8("line_6"));
        line_6->setGeometry(QRect(850, 110, 251, 20));
        line_6->setMidLineWidth(2);
        line_6->setFrameShape(QFrame::HLine);
        line_6->setFrameShadow(QFrame::Sunken);
        line_7 = new QFrame(ScorerView);
        line_7->setObjectName(QString::fromUtf8("line_7"));
        line_7->setGeometry(QRect(840, 0, 20, 121));
        line_7->setMidLineWidth(2);
        line_7->setFrameShape(QFrame::VLine);
        line_7->setFrameShadow(QFrame::Sunken);
        label_4 = new QLabel(ScorerView);
        label_4->setObjectName(QString::fromUtf8("label_4"));
        label_4->setGeometry(QRect(860, 10, 101, 31));
        pushButton = new QPushButton(ScorerView);
        pushButton->setObjectName(QString::fromUtf8("pushButton"));
        pushButton->setGeometry(QRect(860, 90, 75, 23));
        pushButton_2 = new QPushButton(ScorerView);
        pushButton_2->setObjectName(QString::fromUtf8("pushButton_2"));
        pushButton_2->setGeometry(QRect(970, 90, 75, 23));
        label_5 = new QLabel(ScorerView);
        label_5->setObjectName(QString::fromUtf8("label_5"));
        label_5->setGeometry(QRect(10, 570, 91, 31));
        PlayerOneStats = new QRadioButton(ScorerView);
        PlayerOneStats->setObjectName(QString::fromUtf8("PlayerOneStats"));
        PlayerOneStats->setGeometry(QRect(10, 600, 82, 17));
        PlayerTwoStats = new QRadioButton(ScorerView);
        PlayerTwoStats->setObjectName(QString::fromUtf8("PlayerTwoStats"));
        PlayerTwoStats->setGeometry(QRect(10, 620, 82, 17));
        PlayerOneAndPlayerTwoStats = new QRadioButton(ScorerView);
        PlayerOneAndPlayerTwoStats->setObjectName(QString::fromUtf8("PlayerOneAndPlayerTwoStats"));
        PlayerOneAndPlayerTwoStats->setGeometry(QRect(10, 640, 82, 17));
        CurrentPlayerStats = new QRadioButton(ScorerView);
        CurrentPlayerStats->setObjectName(QString::fromUtf8("CurrentPlayerStats"));
        CurrentPlayerStats->setGeometry(QRect(10, 660, 111, 17));
        NumberOf180s = new QRadioButton(ScorerView);
        NumberOf180s->setObjectName(QString::fromUtf8("NumberOf180s"));
        NumberOf180s->setGeometry(QRect(130, 600, 70, 17));
        WinPercentages = new QRadioButton(ScorerView);
        WinPercentages->setObjectName(QString::fromUtf8("WinPercentages"));
        WinPercentages->setGeometry(QRect(130, 620, 61, 17));
        PersonalStats = new QRadioButton(ScorerView);
        PersonalStats->setObjectName(QString::fromUtf8("PersonalStats"));
        PersonalStats->setGeometry(QRect(130, 640, 101, 17));
        MatchStats = new QRadioButton(ScorerView);
        MatchStats->setObjectName(QString::fromUtf8("MatchStats"));
        MatchStats->setGeometry(QRect(130, 660, 70, 17));
        RankedStats = new QRadioButton(ScorerView);
        RankedStats->setObjectName(QString::fromUtf8("RankedStats"));
        RankedStats->setGeometry(QRect(250, 600, 70, 17));
        line_8 = new QFrame(ScorerView);
        line_8->setObjectName(QString::fromUtf8("line_8"));
        line_8->setGeometry(QRect(583, 560, 20, 121));
        line_8->setMidLineWidth(2);
        line_8->setFrameShape(QFrame::VLine);
        line_8->setFrameShadow(QFrame::Sunken);
        label_6 = new QLabel(ScorerView);
        label_6->setObjectName(QString::fromUtf8("label_6"));
        label_6->setGeometry(QRect(600, 570, 61, 31));
        pushButton_3 = new QPushButton(ScorerView);
        pushButton_3->setObjectName(QString::fromUtf8("pushButton_3"));
        pushButton_3->setGeometry(QRect(840, 590, 75, 23));
        pushButton_4 = new QPushButton(ScorerView);
        pushButton_4->setObjectName(QString::fromUtf8("pushButton_4"));
        pushButton_4->setGeometry(QRect(840, 630, 75, 23));

        retranslateUi(ScorerView);

        QMetaObject::connectSlotsByName(ScorerView);
    } // setupUi

    void retranslateUi(QDialog *ScorerView)
    {
        ScorerView->setWindowTitle(QCoreApplication::translate("ScorerView", "Dialog", nullptr));
        label->setText(QCoreApplication::translate("ScorerView", "<html><head/><body><p><span style=\" font-size:12pt; font-weight:600;\">Last Throw :</span></p></body></html>", nullptr));
        label_2->setText(QCoreApplication::translate("ScorerView", "<html><head/><body><p><span style=\" font-size:12pt; font-weight:600;\">Current Throw :</span></p></body></html>", nullptr));
        label_3->setText(QCoreApplication::translate("ScorerView", "<html><head/><body><p><span style=\" font-size:12pt; font-weight:600;\">Match Settings :</span></p></body></html>", nullptr));
        label_4->setText(QCoreApplication::translate("ScorerView", "<html><head/><body><p><span style=\" font-size:12pt; font-weight:600;\">Validation: </span></p></body></html>", nullptr));
        pushButton->setText(QCoreApplication::translate("ScorerView", "Yes", nullptr));
        pushButton_2->setText(QCoreApplication::translate("ScorerView", "No", nullptr));
        label_5->setText(QCoreApplication::translate("ScorerView", "<html><head/><body><p><span style=\" font-size:12pt; font-weight:600;\">Display : </span></p></body></html>", nullptr));
        PlayerOneStats->setText(QCoreApplication::translate("ScorerView", "P1 Stats", nullptr));
        PlayerTwoStats->setText(QCoreApplication::translate("ScorerView", "P2 Stats", nullptr));
        PlayerOneAndPlayerTwoStats->setText(QCoreApplication::translate("ScorerView", "Both Stats", nullptr));
        CurrentPlayerStats->setText(QCoreApplication::translate("ScorerView", "Current Player", nullptr));
        NumberOf180s->setText(QCoreApplication::translate("ScorerView", "180's", nullptr));
        WinPercentages->setText(QCoreApplication::translate("ScorerView", "Wins%", nullptr));
        PersonalStats->setText(QCoreApplication::translate("ScorerView", "Pesonal Stats", nullptr));
        MatchStats->setText(QCoreApplication::translate("ScorerView", "Match", nullptr));
        RankedStats->setText(QCoreApplication::translate("ScorerView", "Ranked", nullptr));
        label_6->setText(QCoreApplication::translate("ScorerView", "<html><head/><body><p><span style=\" font-size:12pt; font-weight:600;\">Legs</span><span style=\" font-size:12pt; font-weight:600;\"> :</span></p></body></html>", nullptr));
        pushButton_3->setText(QCoreApplication::translate("ScorerView", "Next Leg", nullptr));
        pushButton_4->setText(QCoreApplication::translate("ScorerView", "Finish Match", nullptr));
    } // retranslateUi

};

namespace Ui {
    class ScorerView: public Ui_ScorerView {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_SCORERVIEW_H
