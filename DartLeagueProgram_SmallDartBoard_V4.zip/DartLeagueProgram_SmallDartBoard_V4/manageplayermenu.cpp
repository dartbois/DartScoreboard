#include "manageplayermenu.h"
#include "ui_manageplayermenu.h"

ManagePlayerMenu::ManagePlayerMenu(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::ManagePlayerMenu)
{
    ui->setupUi(this);
    this->setWindowFlag(Qt::WindowMinMaxButtonsHint);
}

ManagePlayerMenu::~ManagePlayerMenu()
{
    delete ui;
}
