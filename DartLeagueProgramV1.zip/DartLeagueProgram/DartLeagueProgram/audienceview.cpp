#include "audienceview.h"
#include "ui_audienceview.h"
#include "scorerview.h"


AudienceView::AudienceView(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::AudienceView)
{
    ui->setupUi(this);
    this->setWindowTitle("Audience View");

    QString Stats = "                                 ";

    //ui -> StatisticsDisplay

}

AudienceView::~AudienceView()
{
    delete ui;
}


void AudienceView::on_StatisticsDisplay_linkActivated(const QString &link)
{

}
