#include "scorerview.h"
#include "ui_scorerview.h"
#include "audienceview.h"


ScorerView::ScorerView(AudienceView *audienceWindow) :
    //QDialog(parent),
    ui(new Ui::ScorerView)
{
    ui->setupUi(this);
    this->setWindowTitle("Scorer Window");
    QString scoreString = "                                 ";

   // StatisticsDisplay -> setVisible(true);

   // connect(ui_NumberOf180s, SIGNAL(clicked()), AudienceView::StatisticsDisplay, SLOT(setText(scoreString)));

   connect(this, &ScorerView::sendPlayerOneStats, audienceWindow, &AudienceView::setText);
}

ScorerView::~ScorerView()
{
    delete ui;
}

void ScorerView::on_PlayerOneStats_clicked()
{
    emit sendPlayerOneStats();
}

void ScorerView::on_PlayerTwoStats_clicked()
{
    emit sendPlayerTwoStats();
}

void ScorerView::on_PlayerOneAndPlayerTwoStats_clicked()
{
    emit sendPlayerOneAndPlayerTwoStats();
}

void ScorerView::on_CurrentPlayerStats_clicked()
{
    emit sendCurrentPlayerStats();
}

void ScorerView::on_NumberOf180s_clicked()
{
    emit sendNumberOf180s();
}

void ScorerView::on_WinPercentages_clicked()
{
    emit sendWinPercentages();
}

void ScorerView::on_PersonalStats_clicked()
{
    emit sendPersonalStats();
}
void ScorerView::on_MatchStats_clicked()
{
    emit sendMatchStats();
}

void ScorerView::on_RankedStats_clicked()
{
    emit sendRankedStats();
}
