/********************************************************************************
** Form generated from reading UI file 'audienceview.ui'
**
** Created by: Qt User Interface Compiler version 5.14.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_AUDIENCEVIEW_H
#define UI_AUDIENCEVIEW_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialog>
#include <QtWidgets/QFrame>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QTableWidget>

QT_BEGIN_NAMESPACE

class Ui_AudienceView
{
public:
    QFrame *line;
    QFrame *line_2;
    QFrame *line_3;
    QLabel *label;
    QFrame *line_4;
    QFrame *line_5;
    QTableWidget *tableWidget;
    QLabel *label_2;
    QFrame *line_6;
    QLabel *label_3;
    QLabel *StatisticsDisplay;
    QLabel *label_4;

    void setupUi(QDialog *AudienceView)
    {
        if (AudienceView->objectName().isEmpty())
            AudienceView->setObjectName(QString::fromUtf8("AudienceView"));
        AudienceView->resize(1260, 686);
        line = new QFrame(AudienceView);
        line->setObjectName(QString::fromUtf8("line"));
        line->setGeometry(QRect(10, 90, 1071, 20));
        line->setMidLineWidth(2);
        line->setFrameShape(QFrame::HLine);
        line->setFrameShadow(QFrame::Sunken);
        line_2 = new QFrame(AudienceView);
        line_2->setObjectName(QString::fromUtf8("line_2"));
        line_2->setGeometry(QRect(1070, 10, 20, 671));
        line_2->setMidLineWidth(2);
        line_2->setFrameShape(QFrame::VLine);
        line_2->setFrameShadow(QFrame::Sunken);
        line_3 = new QFrame(AudienceView);
        line_3->setObjectName(QString::fromUtf8("line_3"));
        line_3->setGeometry(QRect(7, 580, 1241, 20));
        line_3->setMidLineWidth(2);
        line_3->setFrameShape(QFrame::HLine);
        line_3->setFrameShadow(QFrame::Sunken);
        label = new QLabel(AudienceView);
        label->setObjectName(QString::fromUtf8("label"));
        label->setGeometry(QRect(20, 40, 261, 41));
        line_4 = new QFrame(AudienceView);
        line_4->setObjectName(QString::fromUtf8("line_4"));
        line_4->setGeometry(QRect(200, 20, 21, 61));
        line_4->setLineWidth(0);
        line_4->setMidLineWidth(5);
        line_4->setFrameShape(QFrame::VLine);
        line_4->setFrameShadow(QFrame::Sunken);
        line_5 = new QFrame(AudienceView);
        line_5->setObjectName(QString::fromUtf8("line_5"));
        line_5->setGeometry(QRect(390, 40, 501, 16));
        line_5->setMidLineWidth(3);
        line_5->setFrameShape(QFrame::HLine);
        line_5->setFrameShadow(QFrame::Sunken);
        tableWidget = new QTableWidget(AudienceView);
        tableWidget->setObjectName(QString::fromUtf8("tableWidget"));
        tableWidget->setGeometry(QRect(1080, 0, 181, 601));
        label_2 = new QLabel(AudienceView);
        label_2->setObjectName(QString::fromUtf8("label_2"));
        label_2->setGeometry(QRect(10, 120, 131, 41));
        line_6 = new QFrame(AudienceView);
        line_6->setObjectName(QString::fromUtf8("line_6"));
        line_6->setGeometry(QRect(140, 100, 20, 491));
        line_6->setMidLineWidth(2);
        line_6->setFrameShape(QFrame::VLine);
        line_6->setFrameShadow(QFrame::Sunken);
        label_3 = new QLabel(AudienceView);
        label_3->setObjectName(QString::fromUtf8("label_3"));
        label_3->setGeometry(QRect(10, 600, 61, 31));
        StatisticsDisplay = new QLabel(AudienceView);
        StatisticsDisplay->setObjectName(QString::fromUtf8("StatisticsDisplay"));
        StatisticsDisplay->setGeometry(QRect(70, 600, 251, 51));
        label_4 = new QLabel(AudienceView);
        label_4->setObjectName(QString::fromUtf8("label_4"));
        label_4->setGeometry(QRect(1086, 602, 171, 81));
        label_4->setPixmap(QPixmap(QString::fromUtf8("../../../Pictures/raidCapture.PNG")));

        retranslateUi(AudienceView);

        QMetaObject::connectSlotsByName(AudienceView);
    } // setupUi

    void retranslateUi(QDialog *AudienceView)
    {
        AudienceView->setWindowTitle(QCoreApplication::translate("AudienceView", "Dialog", nullptr));
        label->setText(QCoreApplication::translate("AudienceView", "<html><head/><body><p><span style=\" font-size:12pt; font-weight:600; color:#aa0000;\">Win Predictions</span></p></body></html>", nullptr));
        label_2->setText(QCoreApplication::translate("AudienceView", "<html><head/><body><p><span style=\" font-size:12pt; font-weight:600;\">Latest Throws :</span></p></body></html>", nullptr));
        label_3->setText(QCoreApplication::translate("AudienceView", "<html><head/><body><p><span style=\" font-size:12pt; font-weight:600;\">Stats :</span></p></body></html>", nullptr));
        StatisticsDisplay->setText(QCoreApplication::translate("AudienceView", "TextLabel", nullptr));
        label_4->setText(QString());
    } // retranslateUi

};

namespace Ui {
    class AudienceView: public Ui_AudienceView {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_AUDIENCEVIEW_H
