/********************************************************************************
** Form generated from reading UI file 'managegamemenu.ui'
**
** Created by: Qt User Interface Compiler version 5.14.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MANAGEGAMEMENU_H
#define UI_MANAGEGAMEMENU_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialog>
#include <QtWidgets/QDialogButtonBox>
#include <QtWidgets/QLabel>

QT_BEGIN_NAMESPACE

class Ui_ManageGameMenu
{
public:
    QDialogButtonBox *buttonBox;
    QLabel *label;

    void setupUi(QDialog *ManageGameMenu)
    {
        if (ManageGameMenu->objectName().isEmpty())
            ManageGameMenu->setObjectName(QString::fromUtf8("ManageGameMenu"));
        ManageGameMenu->resize(400, 300);
        buttonBox = new QDialogButtonBox(ManageGameMenu);
        buttonBox->setObjectName(QString::fromUtf8("buttonBox"));
        buttonBox->setGeometry(QRect(30, 240, 341, 32));
        buttonBox->setOrientation(Qt::Horizontal);
        buttonBox->setStandardButtons(QDialogButtonBox::Cancel|QDialogButtonBox::Ok);
        label = new QLabel(ManageGameMenu);
        label->setObjectName(QString::fromUtf8("label"));
        label->setGeometry(QRect(90, 40, 231, 16));

        retranslateUi(ManageGameMenu);
        QObject::connect(buttonBox, SIGNAL(accepted()), ManageGameMenu, SLOT(accept()));
        QObject::connect(buttonBox, SIGNAL(rejected()), ManageGameMenu, SLOT(reject()));

        QMetaObject::connectSlotsByName(ManageGameMenu);
    } // setupUi

    void retranslateUi(QDialog *ManageGameMenu)
    {
        ManageGameMenu->setWindowTitle(QCoreApplication::translate("ManageGameMenu", "Dialog", nullptr));
        label->setText(QCoreApplication::translate("ManageGameMenu", "This is where you can manage games!", nullptr));
    } // retranslateUi

};

namespace Ui {
    class ManageGameMenu: public Ui_ManageGameMenu {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MANAGEGAMEMENU_H
