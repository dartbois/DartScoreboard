#ifndef AUDIENCEVIEW_H
#define AUDIENCEVIEW_H

#include <QDialog>
#include <QLabel>



namespace Ui {
class AudienceView;
}

class AudienceView : public QDialog
{
    Q_OBJECT

public:
    explicit AudienceView(QWidget *parent = nullptr);
    ~AudienceView();

public slots:
    //void on_label_4_linkActivated(const QString &link);

    void on_StatisticsDisplay_linkActivated(const QString &link);

public:
    Ui::AudienceView *ui;
    //static Ui::AudienceView *ui = new Ui::AudienceView();
    //QLabel *StatsDisplay;
   QLabel *StatisticsDisplay;


};

#endif // AUDIENCEVIEW_H
