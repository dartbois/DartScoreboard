#include "scorerview.h"
#include "ui_scorerview.h"
#include "audienceview.h"


ScorerView::ScorerView(AudienceView *audienceWindow) :
    //QDialog(parent),
    ui(new Ui::ScorerView)
{
    ui->setupUi(this);
    this->setWindowTitle("Scorer Window");

    QString scoreString = "                                 ";

   // StatisticsDisplay -> setVisible(true);

   // connect(ui_NumberOf180s, SIGNAL(clicked()), AudienceView::StatisticsDisplay, SLOT(setText(scoreString)));

   connect(ui -> NumberOf180s, SIGNAL(clicked()), audienceWindow, SLOT(setText()));
}

ScorerView::~ScorerView()
{
    delete ui;
}

void ScorerView::on_PlayerOneStats_clicked()
{
  //QLabel StatisticsDisplay = ui_StatisticsDisplay->setText("Player One Stats: ");

}

void ScorerView::on_PlayerTwoStats_clicked()
{
    StatisticsDisplay->setText("Player Two Stats: ");
}

void ScorerView::on_PlayerOneAndPlayerTwoStats_clicked()
{
     StatisticsDisplay->setText("Player One and Player Two Stats: ");
}

void ScorerView::on_CurrentPlayerStats_clicked()
{
     StatisticsDisplay->setText("Current player stats: ");
}

void ScorerView::on_NumberOf180s_clicked()
{
    StatisticsDisplay->setText("Number of 180s: ");
}

void ScorerView::on_WinPercentages_clicked()
{
    StatisticsDisplay->setText("Current Win Percentages: ");
}

void ScorerView::on_PersonalStats_clicked()
{
     StatisticsDisplay->setText("Players Personal Stats: ");
}
void ScorerView::on_MatchStats_clicked()
{
    StatisticsDisplay->setText("Players Personal Stats: ");
}

void ScorerView::on_RankedStats_clicked()
{
     StatisticsDisplay->setText("Player Ranked statatistics:  ");
}
